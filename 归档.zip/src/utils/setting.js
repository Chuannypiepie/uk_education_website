import config from '../../package.json';
export default {
  currentVersion: `v${config.version}-rc`,
  qq: '89165685',
  customQQ: '353087890',
  officialAccount: '知码前端',
};
