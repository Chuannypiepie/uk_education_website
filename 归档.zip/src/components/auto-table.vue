
<script>
export default {
  name: 'AutoTable',
  render() {
    return (<div>傻逼</div>);
  },
};
</script>

<style scoped>

</style>
