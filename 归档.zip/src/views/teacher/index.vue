<template>
  <div class="main-container student">
    <TableHeader
      title="老师编辑"
      :can-collapsed="false"
    >
      <template slot="right">
        <el-button
          type="primary"
          size="mini"
          :icon="orderByTime?'el-icon-sort-up':'el-icon-sort-down'"
          @click="reverseSort"
        >时间排序
        </el-button>
        <el-button
          type="primary"
          size="mini"
          icon="el-icon-plus"
          @click="openAddRole"
        >添加
        </el-button>
      </template>
    </TableHeader>
    <el-card class="search-card">
      <el-form :inline="true" :model="searchFrom" class="demo-form-inline">
        <el-form-item label="高级搜索" />
        <el-form-item label="名称">
          <el-input v-model="searchFrom.userName" size="mini" placeholder="名称" />
        </el-form-item>
        <el-form-item label="邮箱">
          <el-input v-model="searchFrom.userEmail" size="mini" placeholder="邮箱" />
        </el-form-item>
        <el-form-item label="电话">
          <el-input v-model="searchFrom.userPhone" size="mini" placeholder="电话" />
        </el-form-item>
        <el-form-item label="账号状态">
          <el-select v-model="searchFrom.isDel" size="mini" placeholder="请选择账号状态">
            <el-option label="正常" value="0" />
            <el-option label="删除" value="1" />
          </el-select>
          <!-- <el-input v-model="searchFrom.isDel" size="mini" placeholder="审批人" /> -->
        </el-form-item>
        <el-form-item>
          <el-button type="primary" size="mini" @click="searchWordChange">查询</el-button>
        </el-form-item>
      </el-form>
    </el-card>
    <TableBody ref="tableBody">
      <el-table
        ref="table"
        v-loading="tableLoading"
        :data="dataList"
      ><el-table-column
        align="center"
        label="操作"
      >
        <template slot-scope="scope">
          <el-link type="primary" :underline="false" @click="openEditRole(scope.row)">编辑</el-link>
          <el-link
            type="danger"
            :underline="false"
            @click="deleteRole(scope.row)"
          >删除</el-link>
        </template>
      </el-table-column>
      </el-table>
    </TableBody>
    <el-card
      :body-style="{ padding: 0 }"
      class="table-footer-container"
      shadow="never"
    >
      <div class="flex">
        <el-pagination
          :current-page.sync="pageNo"
          :page-size="pageSize"
          layout="prev, pager, next, jumper"
          :total="totalSize"
          @current-change="currentChanged"
        />
      </div>
    </el-card>
    <!-- TODO需要修改 -->
    <el-dialog :title="isNewRole?'添加角色':'编辑角色'" :visible.sync="dialogEditVisible">
      <el-form ref="form" :model="editFrom" label-width="150px" label-position="left">
        <el-form-item label="user Name">
          <el-input v-model="editFrom.userName" disabled />
        </el-form-item>
        <el-form-item label="user Email">
          <el-input v-model="editFrom.userEmail" disabled />
        </el-form-item>
        <el-form-item label="user Phone">
          <el-input v-model="editFrom.userPhone" :disabled="!isNewRole" />
        </el-form-item>
        <!-- TODO修改为图片上传 -->
        <el-form-item label="userAvatar">
          <el-input v-model="editFrom.userAvatar" />
        </el-form-item>
        <el-form-item label="loginPassword">
          <el-input v-model="editFrom.loginPassword" type="textarea" />
        </el-form-item>
        <el-form-item label="permission name">
          <el-select v-model="permissioActive" placeholder="请选择添加权限">
            <el-option
              v-for="item in permissioList"
              :key="item.roleNames+'_permissio'"
              :label="item.permissionAlias"
              :value="item.roleNames"
            />
          </el-select>
          <el-button @click="addTab(permissioActive)">添加权限</el-button>
        </el-form-item>
        <el-form-item label="permissionList">
          <el-tag
            v-for="tag in editFrom.roleNames"
            :key="tag+'_tab'"
            closable
            :disable-transitions="false"
            @close="tabClose(tag)"
          >
            {{ tag }}
          </el-tag>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogEditVisible = false">取 消</el-button>
        <el-button type="primary" @click="confirmClick(isNewRole)">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
import * as teacherApi from '@/api/teacher-api';
import { RoleModel } from '@/api/model';
export default {
  name: 'TeacherView',
  data: () => ({
    tableLoading: false,
    /** @type {Boolean} - 判断是新增还修改 在点击时候改变 */
    isNewRole: false,
    /** @type {Boolean} - 展示dialog */
    dialogEditVisible: false,
    /**
     * @type {Array<RoleModel>}
     * @description 表格数据
     */
    dataList: [],
    /**
     * @type {String}
     * @description 渲染的tabs
     */
    tabs: [ ],
    /** @type {RoleModel} 编辑添加表单 */
    editFrom: new RoleModel({}),
    /** @type {Array<PermissioModel>} - 权限列表 */
    permissioList: [],
    permissioActive: '',
    /** @type {RoleModel}  搜索条件表单*/
    searchFrom: new RoleModel({}),
    // 页码控制
    pageNo: 1,
    pageSize: 10,
    totalSize: 20,
    searchWord: '',
    orderByTime: false, // 0 : 1
    startTime: 0,
    endTime: 0,
  }),
  methods: {
    /**
     * @method
     * @description 修改时间排序然后获取表 */
    reverseSort() {
      this.pageNo = 1;
      this.pageSize = 10;
      this.orderByTime = !this.orderByTime;
      this.getTable();
    },
    /**
     * @method
     * @description  修改搜索条件然后获取表 按钮触发 */
    searchWordChange() {
      this.pageNo = 1;
      this.pageSize = 10;
      this.getTable();
    },
    /** @method
     * @description 页面改变
     * @param {Number} data -页码
    */
    currentChanged(data) {
      console.log('页码改变', data, this.pageNo);
      this.getTable();
    },
    /** @method
     * @description 重置表格获取表格
    */
    refreshTable() {
      this.pageNo = 1;
      this.pageSize = 10;
      this.searchWord = null;
      this.orderByTime = false;
      this.searchFrom = new RoleModel({});
      this.getTable();
    },
    /** @method
     * @description 只获取信息列表不做操作
    */
    getTable() {
      this.tableLoading = true;
      teacherApi.getPageMasterInfo({
        teacherInfo: this.searchFrom,
        pageNo: this.pageNo,
        pageSize: this.pageSize,
        searchWord: this.searchWord,
        timeType: this.orderByTime,
        startTime: this.startTime,
        endTime: this.endTime === 0 ? new Date().getTime() : this.endTime,
      }).then(res => {
        console.log('成功返回', res);
      }, (error) => {
        console.log('失败返回', error);
      });
    },
    /**
     * @method
     * @description 传入角色详情并打开编辑框
     * @param {RoleModel} res - 传入角色模型
     */
    openEditRole(res) {
      this.isNewRole = false;
      // teacherApi.masterExcel(res).then((result) => {
      //   console.log('表格详情', new RoleModel(result.result));
      this.editFrom = res;
      this.dialogEditVisible = true;
    },
    /**
     * @method
     * @description 请求角色详情并打开编辑框
     * @param {RoleItem} res - 角色模型
     */
    openAddRole() {
      this.isNewRole = true;
      this.editFrom = new RoleModel({});
      this.dialogEditVisible = true;
    },
    /**
     * @method
     * @description 提交按钮是分流编辑或者添加
     * @param {boolean} isNew - true添加 false修改
     * */
    confirmClick(isNew) {
      if (isNew) {
        console.log('添加角色');
        this.createRole();
      } else {
        console.log('编辑角色');
        this.submitEditRole();
      }
    },
    /**
     * @method
     * @description 编辑表删除tabs
     * @param {String} tagName - 权限名
     */
    tabClose(tagName) {
      console.log(tagName);
      const index = this.editFrom.roleNames.indexOf(tagName);
      if (index !== -1) {
        this.editFrom.roleNames.splice(index, 1);
      }
      // console.log(this.form.permissionNames);
    },
    /**
     * @method
     * @description 编辑表添加tabs
     * @param {String} tagName - 权限名
     */
    addTab(tagName) {
      console.log(tagName);
      if (tagName === '') {
        return;
      }
      const index = this.editFrom.roleNames.indexOf(tagName);
      if (index === -1) {
        this.editFrom.roleNames.unshift(tagName);
      }
      // console.log(this.form.permissionNames);
    },
    /**
     * @method
     * @description 提交角色编辑成功后关闭编辑框
     * @param {RoleModel} data - 角色模型
     */
    submitEditRole() {
      console.log(this.editFrom);
      teacherApi.updateMaster({
        teacherInfo: this.editFrom,
        pageNo: 1,
        pageSize: 10,
        searchWord: null,
        timeType: 0,
        startTime: 0,
        endTime: Math.floor(new Date().getTime() / 1000),
      }).then(res => {
        console.log(res);
        this.dialogEditVisible = false;
        this.refreshTable();
      }, (error) => {
        console.log(error);
        this.$message.error('错了哦，这是一条错误消息');
      });
    },
    /**
     * @method
     * @description 增加角色编辑成功后关闭编辑框
     * @param {RoleModel} data - 角色模型
     */
    createRole() {
      console.log(this.editFrom);
      teacherApi.addMaster({
        teacherInfo: this.editFrom,
        pageNo: 1,
        pageSize: 10,
        searchWord: null,
        timeType: 0,
        startTime: 0,
        endTime: Math.floor(new Date().getTime() / 1000),
      }).then(res => {
        console.log(res);
        this.dialogEditVisible = false;
        this.refreshRoleList();
      }, (error) => {
        console.log(error);
        this.$message.error('错了哦，这是一条错误消息');
      });
    },
    /**
     * @method
     * @description 删除角色
     * @param {RoleModel} data - 角色模型
     */
    deleteRole(data) {
      this.$confirm('此操作将永久删除该用户, 是否继续?', '重要提示', {
        confirmButtonText: '删除',
        cancelButtonText: '再想想',
        type: 'warning',
      }).then(() => {
        console.log(data);
        teacherApi.deleteMaster(data).then(res => {
          console.log(res);
          this.$message({
            type: 'success',
            message: '删除成功!',
          });
        });
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除',
        });
      });
      // console.log(this.form.permissionNames);
    },
  },
};
</script>

<style scoped>
.student .search-card.el-card {
  margin-bottom: 10px;
  box-shadow: none;
}
</style>
