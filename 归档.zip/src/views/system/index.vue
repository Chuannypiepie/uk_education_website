<template>
  <div>
    system
  </div>
</template>

<script>
export default {
  name: 'System',
};
</script>

<style>

</style>

