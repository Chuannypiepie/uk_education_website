import * as axios from './http.js';
import { LessonModel } from './model.js';
LessonModel;

/**
 * @desc POST 为老师添加修改关联课程
 * @host /admin/auth/allotMasterCurriculum
 * @param {Object} option - 传入值
 * @param {LessonModel} option.lessonModel	 - 课程信息
 * @param {LessonModel} option.pageNo	 - 页码
 * @param {LessonModel} option.pageSize	 - 页大小
 * @param {LessonModel} option.searchWord	 - 搜索词
 * @param {LessonModel} option.timeType	 - 按创建时间排序 0倒序，1升序
 * @param {LessonModel} option.startTime	 - 创建/注册时间区间 大于该值
 * @param {LessonModel} option.endTime	 - 创建/注册时间区间 小于该值
 * @returns {object} 返回值
 */
export const allotMasterCurriculum = function({
  lessonModel,
  pageNo,
  pageSize,
  searchWord,
  timeType,
  startTime,
  endTime,
}) {
  return axios.http({
    url: '/admin/auth/allotMasterCurriculum',
    method: 'POST',
    data: {
      ...lessonModel.toMpa(),
      pageParameter: {
        pageNo,
        pageSize,
        searchWord,
        timeType,
        startTime,
        endTime,
      },
    },
  });
};

/**
 * @desc POST 为学生关联课程
 * @host /admin/auth/allotStudentCurriculum
 * @param {Object} option - 传入值
 * @param {LessonModel} option.lessonModel	 - 课程信息
 * @param {LessonModel} option.pageNo	 - 页码
 * @param {LessonModel} option.pageSize	 - 页大小
 * @param {LessonModel} option.searchWord	 - 搜索词
 * @param {LessonModel} option.timeType	 - 按创建时间排序 0倒序，1升序
 * @param {LessonModel} option.startTime	 - 创建/注册时间区间 大于该值
 * @param {LessonModel} option.endTime	 - 创建/注册时间区间 小于该值
 * @returns {object} 返回值
 */
export const allotStudentCurriculum = function({
  lessonModel,
  pageNo,
  pageSize,
  searchWord,
  timeType,
  startTime,
  endTime,
}) {
  return axios.http({
    url: '/admin/auth/allotStudentCurriculum',
    method: 'POST',
    data: {
      ...lessonModel.toMpa(),
      pageParameter: {
        pageNo,
        pageSize,
        searchWord,
        timeType,
        startTime,
        endTime,
      },
    },
  });
};

/**
 * @desc POST 取消学生关联的课程
 * @host /admin/auth/removeStudentCurriculum
 * @param {Object} option - 传入值
 * @param {LessonModel} option.lessonModel	 - 课程信息
 * @param {LessonModel} option.pageNo	 - 页码
 * @param {LessonModel} option.pageSize	 - 页大小
 * @param {LessonModel} option.searchWord	 - 搜索词
 * @param {LessonModel} option.timeType	 - 按创建时间排序 0倒序，1升序
 * @param {LessonModel} option.startTime	 - 创建/注册时间区间 大于该值
 * @param {LessonModel} option.endTime	 - 创建/注册时间区间 小于该值
 * @returns {object} 返回值
 */
export const removeStudentCurriculum = function({
  lessonModel,
  pageNo,
  pageSize,
  searchWord,
  timeType,
  startTime,
  endTime,
}) {
  return axios.http({
    url: '/admin/auth/removeStudentCurriculum',
    method: 'POST',
    data: {
      ...lessonModel.toMpa(),
      pageParameter: {
        pageNo,
        pageSize,
        searchWord,
        timeType,
        startTime,
        endTime,
      },
    },
  });
};

/**
 * @desc POST 后台添加课程
 * @host /admin/auth/addCurriculum
 * @param {Object} option - 传入值
 * @param {LessonModel} option.lessonModel	 - 课程信息
 * @param {LessonModel} option.pageNo	 - 页码
 * @param {LessonModel} option.pageSize	 - 页大小
 * @param {LessonModel} option.searchWord	 - 搜索词
 * @param {LessonModel} option.timeType	 - 按创建时间排序 0倒序，1升序
 * @param {LessonModel} option.startTime	 - 创建/注册时间区间 大于该值
 * @param {LessonModel} option.endTime	 - 创建/注册时间区间 小于该值
 * @returns {object} 返回值
 */
export const addCurriculum = function({
  lessonModel,
  pageNo,
  pageSize,
  searchWord,
  timeType,
  startTime,
  endTime,
}) {
  return axios.http({
    url: '/admin/auth/addCurriculum',
    method: 'POST',
    data: {
      ...lessonModel.toMpa(),
      pageParameter: {
        pageNo,
        pageSize,
        searchWord,
        timeType,
        startTime,
        endTime,
      },
    },
  });
};

/**
 * @desc POST 修改课程信息
 * @host /admin/auth/updateCurriculum
 * @param {Object} option - 传入值
 * @param {LessonModel} option.lessonModel	 - 课程信息
 * @param {LessonModel} option.pageNo	 - 页码
 * @param {LessonModel} option.pageSize	 - 页大小
 * @param {LessonModel} option.searchWord	 - 搜索词
 * @param {LessonModel} option.timeType	 - 按创建时间排序 0倒序，1升序
 * @param {LessonModel} option.startTime	 - 创建/注册时间区间 大于该值
 * @param {LessonModel} option.endTime	 - 创建/注册时间区间 小于该值
 * @returns {object} 返回值
 */
export const updateCurriculum = function({
  lessonModel,
  pageNo,
  pageSize,
  searchWord,
  timeType,
  startTime,
  endTime,
}) {
  return axios.http({
    url: '/admin/auth/updateCurriculum',
    method: 'POST',
    data: {
      ...lessonModel.toMpa(),
      pageParameter: {
        pageNo,
        pageSize,
        searchWord,
        timeType,
        startTime,
        endTime,
      },
    },
  });
};

/**
 * @desc DELETE 删除课程 假删除
 * @host /admin/auth/deleteCurriculum/
 * @param {Object} option - 传入值
 * @param {int} option.cid	 - 应该是课程id吧
 * @returns {object} 返回值
 */
export const deleteCurriculum = function({
  cid,
}) {
  return axios.http({
    url: '/admin/auth/deleteCurriculum/' + cid,
    method: 'DELETE',
  });
};

/**
 * @desc POST 分页多条件查询 课程信息
 * @host /admin/auth/getPageCurriculumInfo
 * @param {Object} option - 传入值
 * @param {LessonModel} option.lessonModel	 - 课程信息
 * @param {LessonModel} option.pageNo	 - 页码
 * @param {LessonModel} option.pageSize	 - 页大小
 * @param {LessonModel} option.searchWord	 - 搜索词
 * @param {LessonModel} option.timeType	 - 按创建时间排序 0倒序，1升序
 * @param {LessonModel} option.startTime	 - 创建/注册时间区间 大于该值
 * @param {LessonModel} option.endTime	 - 创建/注册时间区间 小于该值
 * @returns {object} 返回值
 */
export const getPageCurriculumInfo = function({
  lessonModel,
  pageNo,
  pageSize,
  searchWord,
  timeType,
  startTime,
  endTime,
}) {
  return axios.http({
    url: '/admin/auth/getPageCurriculumInfo',
    method: 'POST',
    data: {
      ...lessonModel.toMpa(),
      pageParameter: {
        pageNo,
        pageSize,
        searchWord,
        timeType,
        startTime,
        endTime,
      },
    },
  });
};

/**
 * @desc POST 审批课程
 * @host /admin/auth/approvalCurriculum
 * @param {Object} option - 传入值
 * @param {LessonModel} option.lessonModel	 - 课程信息
 * @param {LessonModel} option.pageNo	 - 页码
 * @param {LessonModel} option.pageSize	 - 页大小
 * @param {LessonModel} option.searchWord	 - 搜索词
 * @param {LessonModel} option.timeType	 - 按创建时间排序 0倒序，1升序
 * @param {LessonModel} option.startTime	 - 创建/注册时间区间 大于该值
 * @param {LessonModel} option.endTime	 - 创建/注册时间区间 小于该值
 * @returns {object} 返回值
 */
export const approvalCurriculum = function({
  lessonModel,
  pageNo,
  pageSize,
  searchWord,
  timeType,
  startTime,
  endTime,
}) {
  return axios.http({
    url: '/admin/auth/approvalCurriculum',
    method: 'POST',
    data: {
      ...lessonModel.toMpa(),
      pageParameter: {
        pageNo,
        pageSize,
        searchWord,
        timeType,
        startTime,
        endTime,
      },
    },
  });
};

/**
 * @desc POST 查询课程审核记录
 * @host /admin/auth/getPageCurriculumCheck
 * @param {Object} option - 传入值
 * @param {LessonModel} option.lessonModel	 - 课程信息
 * @param {LessonModel} option.pageNo	 - 页码
 * @param {LessonModel} option.pageSize	 - 页大小
 * @param {LessonModel} option.searchWord	 - 搜索词
 * @param {LessonModel} option.timeType	 - 按创建时间排序 0倒序，1升序
 * @param {LessonModel} option.startTime	 - 创建/注册时间区间 大于该值
 * @param {LessonModel} option.endTime	 - 创建/注册时间区间 小于该值
 * @returns {object} 返回值
 */
export const getPageCurriculumCheck = function({
  lessonModel,
  pageNo,
  pageSize,
  searchWord,
  timeType,
  startTime,
  endTime,
}) {
  return axios.http({
    url: '/admin/auth/getPageCurriculumCheck',
    method: 'POST',
    data: {
      ...lessonModel.toMpa(),
      pageParameter: {
        pageNo,
        pageSize,
        searchWord,
        timeType,
        startTime,
        endTime,
      },
    },
  });
};

/**
 * @desc GET 查询课程详细信息
 * @host /admin/auth/getCurriculumCheckInfo/
 * @param {Object} option - 传入值
 * @param {int} option.cid	 - 应该是课程id吧
 * @returns {object} 返回值
 */
export const getCurriculumCheckInfo = function({
  CCid,
}) {
  return axios.http({
    url: '/admin/auth/getCurriculumCheckInfo/' + CCid,
    method: 'GET',
  });
};

/**
 * @desc POST 多条件分页查询 课程资料
 * @host /admin/auth/getCurriculumDataPageInfo
 * @param {Object} option - 传入值
 * @param {int} option.id	 - ???
 * @param {LessonModel} option.dataLink	 - 教学资料链接
 * @param {LessonModel} option.dataName	 - 资料名称
 * @param {LessonModel} option.content	 - 备注、作用
 * @param {LessonModel} option.curriculumId	 - 课程id
 * @param {LessonModel} option.masterId	 - 老师id
 * @param {LessonModel} option.status	 - 审核状态 0待审核、1同意、2拒绝
 * @param {LessonModel} option.createTime	 - 创建时间
 * @param {LessonModel} option.pageNo	 - 页码
 * @param {LessonModel} option.pageSize	 - 页大小
 * @param {LessonModel} option.searchWord	 - 搜索词
 * @param {LessonModel} option.timeType	 - 按创建时间排序 0倒序，1升序
 * @param {LessonModel} option.startTime	 - 创建/注册时间区间 大于该值
 * @param {LessonModel} option.endTime	 - 创建/注册时间区间 小于该值
 * @returns {object} 返回值
 */
export const getCurriculumDataPageInfo = function({
  lessonModel,
  pageNo,
  pageSize,
  searchWord,
  timeType,
  startTime,
  endTime,
}) {
  return axios.http({
    url: '/admin/auth/getCurriculumDataPageInfo',
    method: 'POST',
    data: {
      ...lessonModel.toMpa(),
      pageParameter: {
        pageNo,
        pageSize,
        searchWord,
        timeType,
        startTime,
        endTime,
      },
    },
  });
};

/**
 * @desc POST 审批课程资料
 * @host /admin/auth/approvalCurriculumData
 * @param {Object} option - 传入值
 * @param {int} option.id	 - ???
 * @param {LessonModel} option.dataLink	 - 教学资料链接
 * @param {LessonModel} option.dataName	 - 资料名称
 * @param {LessonModel} option.content	 - 备注、作用
 * @param {LessonModel} option.curriculumId	 - 课程id
 * @param {LessonModel} option.masterId	 - 老师id
 * @param {LessonModel} option.status	 - 审核状态 0待审核、1同意、2拒绝
 * @param {LessonModel} option.createTime	 - 创建时间
 * @param {LessonModel} option.pageNo	 - 页码
 * @param {LessonModel} option.pageSize	 - 页大小
 * @param {LessonModel} option.searchWord	 - 搜索词
 * @param {LessonModel} option.timeType	 - 按创建时间排序 0倒序，1升序
 * @param {LessonModel} option.startTime	 - 创建/注册时间区间 大于该值
 * @param {LessonModel} option.endTime	 - 创建/注册时间区间 小于该值
 * @returns {object} 返回值
 */
export const approvalCurriculumData = function({
  permissionId,
  lessonModel,
  pageNo,
  pageSize,
  searchWord,
  timeType,
  startTime,
  endTime,
}) {
  return axios.http({
    url: '/admin/auth/approvalCurriculumData',
    method: 'POST',
    data: {
      ...lessonModel.toMpa(),
      pageParameter: {
        pageNo,
        pageSize,
        searchWord,
        timeType,
        startTime,
        endTime,
      },
    },
  });
};
